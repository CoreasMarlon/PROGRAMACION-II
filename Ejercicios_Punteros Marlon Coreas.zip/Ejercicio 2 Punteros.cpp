//Programa creado por: Marlon Salomon Coreas Villanueva
//Carnet: CV18035        Programacion II       Grupo 02
#include <iostream>
#include <conio.h>

using namespace std;

int fun(int *mul){
	int res;
	res = *mul * 10;
	return res;
}

int main() {
	
	int valor;
	cout<<"Ingrese el valor que se almacenara en "<<&valor<<" : ";
	cin>>valor;
	valor = fun(&valor);//La variable "valor" toma el valor retornado por la funcion, que es su valor original ultiplicado por 10.
	cout<<"El nuevo valor es: "<<valor<<" que se almacena en la misma posicion: "<<&valor;
	return 0;
}
