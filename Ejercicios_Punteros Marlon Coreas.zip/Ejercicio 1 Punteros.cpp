//Programa creado por: Marlon Salomon Coreas Villanueva
//Carnet: CV18035        Programacion II       Grupo 02

#include <iostream>
#include <conio.h>

using namespace std;

int a;
int b;

int mayor(int *dir_a, int *dir_b){
	
	int vm;//Utiliza esta variable como auxiliar para almacenar el valor mayor mientras se hace el cambio de valor.
	vm = *dir_b;
	*dir_b = *dir_a;
	*dir_a = vm;	
	
	a = *dir_a;
	return a;
}

int main() {
	
	cout<<"Ingrese el primer valor en la posicion de mamoria "<<&a<< ": ";
	cin>>a;
	cout<<"Ingrese el segundo valor en la posicion de memoria "<<&b<<": ";
	cin>>b;
	
	if (b > a){
	a = mayor(&a, &b);//Se llama la funcion que toma los valores de la variable a y b y el valor retornado se almacena en a.
	cout<<"El segundo valor "<<a<<" es mayor por lo que se almacena en: "<<&a<<endl;
	cout<<"El primer valor "<<b<<" es menor por lo que se almacena en: "<<&b;
	}
	else{
		cout<<"El primer valor es mayor o ambos valores son igules";
	}
	
	getch();
	return 0;
}
