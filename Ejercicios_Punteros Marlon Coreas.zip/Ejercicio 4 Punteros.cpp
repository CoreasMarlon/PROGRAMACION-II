//Programa creado por: Marlon Salomon Coreas Villanueva
//Carnet: CV18035        Programacion II       Grupo 02

#include <iostream>
#include <conio.h>

using namespace std;

 float area(float *largo, float *ancho, float *alto){
 	float a;
 	if (*alto == 0){
		a = ((*largo) * (*ancho));
		cout<<"El area del cuadrado es: "<<a;
	}
	else {
		a = ((*largo) * (*ancho) * (*alto));
		cout<<"El volumen del cubo es: "<<a;
	}
 }


int main() {
	
	float lar;
	float anh;
	float alt;
	
	cout<<"Ingrese el valor del largo: ";
	cin>>lar;
	cout<<"Ingrese el valor del ancho: ";
	cin>>anh;
	cout<<"Ingrese el valor de lo alto: !!!Nota si busca calcular area ingrese cero en este campo!!! "<<endl;
	cin>>alt;

	area(&lar, &anh, &alt);

	return 0;
}
